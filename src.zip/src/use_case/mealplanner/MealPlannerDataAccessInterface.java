package use_case.mealplanner;

import entity.Food;
import java.util.List;
import java.util.Set;

public interface MealPlannerDataAccessInterface {
    List<Food> generateMealOptions(Set<String> dietaryPreferences, String mealType);
    void addMealToUser(String username, String mealType, Food food);
    boolean existsByName(String username);
}