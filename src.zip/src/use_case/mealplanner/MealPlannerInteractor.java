package use_case.mealplanner;

import entity.Food;
import java.util.List;

public class MealPlannerInteractor implements MealPlannerInputBoundary {
    final MealPlannerDataAccessInterface mealPlannerDataAccessObject;
    final MealPlannerOutputBoundary mealPlannerPresenter;

    public MealPlannerInteractor(
            MealPlannerDataAccessInterface dataAccessInterface,
            MealPlannerOutputBoundary outputBoundary) {
        this.mealPlannerDataAccessObject = dataAccessInterface;
        this.mealPlannerPresenter = outputBoundary;
    }

    @Override
    public void execute(MealPlannerInputData inputData) {
        try {
            if (!mealPlannerDataAccessObject.existsByName(inputData.getUsername())) {
                mealPlannerPresenter.prepareFailView("User not found.");
                return;
            }

            // Generate meal options based on dietary preferences
            List<Food> breakfastOptions = mealPlannerDataAccessObject.generateMealOptions(
                    inputData.getDietaryPreferences(), "breakfast"
            );
            List<Food> lunchOptions = mealPlannerDataAccessObject.generateMealOptions(
                    inputData.getDietaryPreferences(), "lunch"
            );
            List<Food> dinnerOptions = mealPlannerDataAccessObject.generateMealOptions(
                    inputData.getDietaryPreferences(), "dinner"
            );

            MealPlannerOutputData outputData = new MealPlannerOutputData(
                    inputData.getUsername(),
                    breakfastOptions,
                    lunchOptions,
                    dinnerOptions,
                    true,
                    null
            );

            mealPlannerPresenter.prepareSuccessView(outputData);

        } catch (Exception e) {
            mealPlannerPresenter.prepareFailView(e.getMessage());
        }
    }

    @Override
    public void addMealToUser(String username, String mealType, Food food) {
        try {
            mealPlannerDataAccessObject.addMealToUser(username, mealType, food);
        } catch (Exception e) {
            mealPlannerPresenter.prepareFailView(e.getMessage());
        }
    }

    @Override
    public void goHome() {
        mealPlannerPresenter.backToDashboard();
    }
}