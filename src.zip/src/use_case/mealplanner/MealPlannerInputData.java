package use_case.mealplanner;

import java.util.Set;

public class MealPlannerInputData {
    private final String username;
    private final Set<String> dietaryPreferences;

    public MealPlannerInputData(String username, Set<String> dietaryPreferences) {
        this.username = username;
        this.dietaryPreferences = dietaryPreferences;
    }

    public String getUsername() { return username; }
    public Set<String> getDietaryPreferences() { return dietaryPreferences; }
}