package use_case.dashboard;

import use_case.mealplanner.MealPlannerOutputData;

public interface DashboardOutputBoundary {
    void prepareSuccessView(DashboardOutputData outputData);
    void prepareSwitchToInfoCollection();
    void prepareSwitchToMealPlanner(MealPlannerOutputData outputData);
    void prepareFailView(String error);
}