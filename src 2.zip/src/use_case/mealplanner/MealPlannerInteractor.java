package use_case.mealplanner;

import data_access.MealPlannerDataAccessObject;
import entity.CommonUser;
import entity.Food;
import entity.MealType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MealPlannerInteractor implements MealPlannerInputBoundary {
    final MealStorageDataAccessInterface mealStorageDataAccessInterface;
    final MealPlannerDataAccessInterface mealPlannerDataAccessObject;
    final MealPlannerOutputBoundary mealPlannerPresenter;

    public MealPlannerInteractor(
            MealStorageDataAccessInterface mealStorageDataAccessInterface,
            MealPlannerDataAccessInterface dataAccessInterface,
            MealPlannerOutputBoundary outputBoundary) {
        this.mealStorageDataAccessInterface = mealStorageDataAccessInterface;
        this.mealPlannerDataAccessObject= dataAccessInterface;
        this.mealPlannerPresenter = outputBoundary;
    }

    @Override
    public void execute(MealPlannerInputData inputData) {
        try {
//            if (!mealStorageDataAccessInterface.existsByName(inputData.getUsername())) {
//                mealPlannerPresenter.prepareFailView("User not found.");
//                return;
            String currentUsername = mealStorageDataAccessInterface.existsByName(inputData.getUsername())
                    ? inputData.getUsername() : null;
            if (currentUsername == null || !mealStorageDataAccessInterface.existsByName(currentUsername)) {
                mealPlannerPresenter.prepareFailView("User not found.");
                return;
            }

//            // Generate meal options based on dietary preferences
//            List<Food> breakfastOptions = mealPlannerDataAccessObject.generateMealOptions(
//                    inputData.getDietaryPreferences(), "breakfast"
//            );
//            List<Food> lunchOptions = mealPlannerDataAccessObject.generateMealOptions(
//                    inputData.getDietaryPreferences(), "lunch"
//            );
//            List<Food> dinnerOptions = mealPlannerDataAccessObject.generateMealOptions(
//                    inputData.getDietaryPreferences(), "dinner"
//            );

            CommonUser user = (CommonUser) mealStorageDataAccessInterface.get(currentUsername);
            Map<MealType, List<Food>> mealPlan = mealPlannerDataAccessObject.generateMealPlan(
                    user,
                    new ArrayList<>(inputData.getDietaryPreferences())
            );


            MealPlannerOutputData outputData = new MealPlannerOutputData(
                    currentUsername,
                    mealPlan.get(MealType.BREAKFAST),
                    mealPlan.get(MealType.LUNCH),
                    mealPlan.get(MealType.DINNER),
                    true,
                    null
            );

            mealPlannerPresenter.prepareSuccessView(outputData);

        } catch (Exception e) {
            mealPlannerPresenter.prepareFailView(e.getMessage());
        }
    }

    @Override
    public void addMealToUser(String username, String mealType, Food food) {
        try {
            mealStorageDataAccessInterface.addMealToUser(username, mealType, food);
        } catch (Exception e) {
            mealPlannerPresenter.prepareFailView(e.getMessage());
        }
    }

    @Override
    public void goHome() {
        mealPlannerPresenter.backToDashboard();
    }
}